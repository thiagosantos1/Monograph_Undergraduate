__global__ void modcpy(void *destination, void *source, size_t destination_size, size_t source_size);
